TB2J magnon downfolding: G-AFM SrMnO3
=====================================

What this example shows
-----------------------
Magnon band structures of G-type antiferromagnetic SrMnO3, computed from
TB2J exchange parameters and downfolded onto the pseudo-cubic primitive
cell. The DFT magnetic cell is larger than the chemical primitive cell
(a sqrt(2) x sqrt(2) x sqrt(2) cell with 10 atoms and 2 Mn at
+/-2.81 muB, propagation vector Q = (1/2, 1/2, 1/2)), so the magnon
bands are folded. The unfolding assigns each folded branch its
primitive-cell momentum and a spectral weight; for a pristine
antiferromagnet the weights are binary (every branch belongs to exactly
one primitive momentum). The G-AFM dispersion is Q-periodic, so the two
folds sharing a stored supercell momentum are exactly degenerate; the
degenerate-group presentation resolves the stored eigenvector gauge and
renders the weights binary. The plot shows weight-coded magnon bands
along the pseudo-cubic path Gamma-X-M-Gamma-R, with a Goldstone mode at
Gamma.

Where data/TB2J_results/TB2J.pickle comes from
----------------------------------------------
The pickle is the output of a TB2J exchange extraction on a
spin-polarized DFT calculation for the G-AFM SrMnO3 supercell:

  1. Run a collinear spin-polarized DFT calculation on the
     sqrt(2) x sqrt(2) x sqrt(2) G-AFM cell (10 atoms, 2 Mn with
     antiparallel moments). The published example used VASP with
     Wannier90; TB2J also supports other codes (e.g. SIESTA, ABINIT,
     QE).
  2. Build Wannier functions and run the TB2J workflow (wannier
     conversion, exchange calculation, collection). TB2J computes the
     exchange tensors J(R) between the two Mn sites from the DFT
     output.
  3. TB2J writes the collected exchange parameters, atomic structure,
     and magnetic moments to TB2J_results/TB2J.pickle.

That pickle (74 KB) is the only upstream artifact in this bundle: no DFT
input files or pseudopotentials are needed to reproduce the figure. It
contains the J(R) tensors, the AFM cell (axes (0,1,1), (1,0,1), (1,1,0)
in pseudo-cubic units), and the Mn moments.

Prerequisites
-------------
- Python 3.9+ with the ``unfolding`` package and its TB2J extra:

    pip install unfolding[tb2j]

- Developed and verified against: unfolding 0.1.0, TB2J 0.9.20,
  ase 3.29.0, numpy 2.2.4, matplotlib 3.11.2. Any reasonably recent
  combination should work; the CLI needs the ``unfolding-magnon``
  console script (installed with the package).
- No DFT code or TB2J extraction run is required: the bundle ships the
  final TB2J pickle.

Commands
--------
From the unpacked bundle directory:

    python reproduce.py

This runs two equivalent routes and checks the physics seals:

  1. The one-command CLI route (what the example page shows):
     unfolding-magnon data/TB2J_results \
         --unfold-mat 0 1 1 1 0 1 1 1 0 \
         --kpath GXMGR --npts 100 \
         --output srmmo3.png --json srmmo3.json
     (reproduce.py falls back to "python -m unfolding.cli_magnon" if the
     console script is not on PATH.)
  2. The Python API route (the docgen figure script): load the pickle,
     set the collinear reference (Q = 0, z axis), build the
     pseudo-cubic q-path from the unfold matrix
     M = [[0,1,1],[1,0,1],[1,1,0]], unfold, and plot.

The CLI can also be run standalone, e.g. with 200 path points to match
the published figure:

    unfolding-magnon data/TB2J_results --unfold-mat 0 1 1 1 0 1 1 1 0 \
        --kpath GXMGR --npts 200 --output magnon_unfolded.png

Expected outputs
----------------
- srmmo3.png            weight-coded unfolded magnon bands (CLI route)
- srmmo3.json           q-points, path axis, energies (meV), weights
- srmmo3_unfolded_api.png  same physics via the Python API

Expected runtime: under 10 seconds on a laptop (2x2 BdG magnon problem
per q-point, 100-200 q-points).

Expected physics seals (asserted by reproduce.py)
-------------------------------------------------
- Goldstone mode at Gamma below 0.05 meV. With the shipped pickle the
  gap comes out essentially zero (< 1e-4 meV); the example page quotes
  ~0.03 meV, set by the small magnetic anisotropy of the exchange set.
- Binary unfolding weights: max |w - nearest(0, 1)| < 1e-8 along the
  whole path. Defects or non-collinear orders would instead produce
  genuinely fractional weights.
