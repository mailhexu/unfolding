====================================================================
SIESTA Si unfolded bands -- reproduction bundle (siesta-si)
====================================================================
Docs example: docs/content/examples/siesta-si.md in the unfolding
repository. Regenerates the figure si_unfolded.png: the committed
8-atom conventional-cubic Si supercell (HSX from a 2x2x2 k-grid SCF)
unfolded onto the 2-atom primitive fcc cell along the high-symmetry
path Gamma-X-W-Gamma-L-W-X, with the independently computed
primitive-cell band structure overlaid in red. Every weight-1
unfolded branch lies on a primitive band, which is the practical
validation of the unfolding.

BUNDLE LAYOUT
  reproduce.py   self-contained script; regenerates the figure
  data/          working copies of the fdf files; the .HSX outputs of
                 the SCF runs are placed here (NOT shipped: binary data)
                   si_prim.fdf / si_prim.HSX    primitive cell (2 atoms)
                   si_sc.fdf   / si_sc.HSX      supercell   (8 atoms)
                 Each fdf sits next to its .HSX because the parser
                 resolves the Hamiltonian archive relative to the fdf.
  inputs/        the same fdf SIESTA inputs (for re-running SIESTA
                 from scratch); data/ keeps the working copies
  pseudos/       pseudopotential notes (see PSEUDOPOTENTIALS below)

PREREQUISITES
  - Python 3.11 with
      numpy 2.2.4, scipy 1.16.0, matplotlib 3.11.2,
      sisl 0.16.2, HamiltonIO 0.3.6,
    and the unfolding package importable (pip install -e <unfolding
    repo checkout>, or PYTHONPATH=<unfolding repo checkout>).
    Tested with unfolding 0.1.0 at main commit 668dde2.
  - A SIESTA installation is needed to (re)generate the .HSX files;
    the bundle ships the fdf inputs and pseudos instead of binary HSX.

HOW THE FIXTURES WERE PRODUCED
  SIESTA development build (>= 5.4, gcc13), GGA/PBE, SZ PAO basis,
  MeshCutoff 100 Ry, SaveHS true.
    si_prim: 2-atom fcc primitive cell, 4x4x4 k-grid SCF.
    si_sc:   8-atom conventional cubic supercell
             (supercell = [[-1,1,1],[1,-1,1],[1,1,-1]] @ primitive),
             2x2x2 k-grid SCF (matched to the primitive 4x4x4).
  A k-sampled SCF is essential: a Gamma-only SaveHS run collapses all
  supercell image shells into a single R=0 block, which cannot be
  unfolded at generic momenta. The regeneration recipe is
  examples/si_example/regenerate_fixtures.sh in the unfolding repo.

COMMANDS
  python reproduce.py                # writes si_unfolded.png here
  python reproduce.py out.png        # or any output path

EXPECTED OUTPUT
  si_unfolded.png (859x650 px, 150 dpi): weight-coded unfolded bands
  in eV with tick labels Gamma X W Gamma L W X, plus the
  primitive-cell bands overlaid in crimson (labelled in the legend).
  Runtime: about 5 s on one core of an Intel i9-13900KF.
  Note: the script reproduces the current docgen pipeline
  (docgen/fig_siesta_si.py) bit-for-bit; if the PNG published on the
  docs page looks older (different weight colormap), the page image
  predates the current pipeline.

PSEUDOPOTENTIALS
  The fdf files name Si.psf (Si, norm-conserving). That file is NOT
  included in this bundle and is NOT needed to reproduce the figure:
  the committed .HSX already carries the Hamiltonian and overlap, and
  the parser never opens the pseudo. You only need Si.psf to re-run
  SIESTA from scratch; it comes from the SIESTA distribution's
  Examples/Si_Optical set (place it next to the fdf inputs).
  See pseudos/PLACEHOLDER-NOT-INCLUDED.txt.
