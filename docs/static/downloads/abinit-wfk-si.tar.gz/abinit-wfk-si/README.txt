ABINIT WFK unfolding bundle: pristine Si and Si:P (8-atom conventional cell)
=============================================================================

WHAT THIS EXAMPLE SHOWS
-----------------------
Unfolding of an ABINIT supercell wavefunction file (WFK, netCDF) onto the
primitive fcc band path Gamma-X-W-Gamma-L-W-X. The planewave basis is
orthonormal, so the spectral weight is a pure reciprocal-coset projection:
for pristine Si every state folds from a single primitive momentum, the
weights are binary, and the unfolded bands ARE the primitive band
structure -- a case with a known answer. Substituting one Si by P (12.5%)
mixes the fold sectors: host bands keep weight near 1 and render as the
darkest traces, while defect-hybridized states carry fractional weight and
appear dimmer. Weights of a normalized state over all fold sectors sum
to 1.

Two figures are produced:

  si8_abinit_unfolded.png   pristine Si 8-atom supercell unfolded onto the
                            path (blue intensity = spectral weight), with
                            the independently computed 2-atom primitive-cell
                            bands overlaid in crimson when the primitive
                            reference WFK is available (see below); after a
                            single constant potential-reference shift the
                            two agree to ~0.07 eV along the whole path.
  si7p_abinit_unfolded.png  Si:P spectral-weight map on the same path.

Physics to check: pristine Si shows the LDA gap of ~0.4-0.5 eV with the
Fermi level mid-gap (indirect Gamma-X gap). If your plot shows a metal
with E_F inside the valence manifold and extra flat singlets below the
top valence triplet at Gamma, you have the ghost-pseudopotential hazard
described below.

BUNDLE LAYOUT
-------------
  inputs/    ABINIT input files (two-dataset decks: SCF + non-SCF path)
             si8_gamma.abi              Si8 SCF at Gamma (ecut 12)
             si7p_gamma.abi             Si7P SCF at Gamma (ecut 12)
             si8_gxwglx_corners.abi     Si8, frozen-density run at the
                                        Gamma/X/W/L corners (ecut 25)
             si7p_gxwglx_corners.abi    Si7P, same corners (ecut 25)
             si7p_gamma_x_path.abi      Si7P, dense 305-point path (ecut 25)
             si8_gxwglwx.abi            pristine Si8, dense 305-point path
                                        (ecut 25) -- regenerates the
                                        published Si8 figure input
             si_primitive_matched.abi   2-atom primitive cell, matched
                                        lattice (ecut 12)
             si_prim_path.abi           2-atom primitive cell, 8x8x8 SCF
                                        + 305-point path in primitive
                                        coordinates (ecut 25) -- the
                                        reference for the crimson overlay
  pseudos/   Troullier-Martins fhi pseudopotentials from the ABINIT
             test-suite Pspdir: 14-Si.nlcc.fhi, 15-P.LDA.fhi
  data/      (empty) WFK output directory; no binary WFK fixtures ship
             with this bundle - run the abinit commands below first
             path runs, 1-11 MB each)
  reproduce.py  renders both figures; run from this directory

PREREQUISITES
-------------
  - Python >= 3.9 with numpy and matplotlib
  - the "unfolding" package, importable (pip install unfolding, or put
    the repository root on PYTHONPATH)
  - only for regenerating the dense WFKs: ABINIT >= 9 built with netCDF
    support (the decks use iomode 3)

EXACT COMMANDS
--------------
Unpack and run from the bundle directory (the directory containing this
README):

  python reproduce.py

NOTE: no WFK files are included; generate at least the corner WFKs
first (commands above). Then: the script renders both PNGs
fixtures. All ABINIT input decks reference their pseudopotentials via
pp_dirpath "." -- run ABINIT in a directory holding the .abi plus the
pseudos (see the printed recipe).

To reproduce the full 305-point published figures, also run the dense
decks (reproduce.py prints these exact commands when the dense WFKs are
missing):

  mkdir -p run_si8 && cd run_si8
  cp ../inputs/si8_gxwglwx.abi ../pseudos/14-Si.nlcc.fhi .
  abinit si8_gxwglwx.abi > si8_gxwglwx.abo 2>&1
  cp si8_gxwglwxo_DS2_WFK.nc ../data/ && cd ..

  mkdir -p run_si7p && cd run_si7p
  cp ../inputs/si7p_gamma_x_path.abi ../pseudos/14-Si.nlcc.fhi ../pseudos/15-P.LDA.fhi .
  abinit si7p_gamma_x_path.abi > si7p_gamma_x_path.abo 2>&1
  cp si7p_gamma_x_patho_DS2_WFK.nc ../data/ && cd ..

  # optional, only for the crimson primitive-cell overlay:
  mkdir -p run_prim && cd run_prim
  cp ../inputs/si_prim_path.abi ../pseudos/14-Si.nlcc.fhi .
  abinit si_prim_path.abi > si_prim_path.abo 2>&1
  cp si_prim_patho_DS2_WFK.nc ../data/ && cd ..

Each deck is a two-dataset run: dataset 1 is an SCF at Gamma (writes the
density), dataset 2 a frozen-density non-SCF run (iscf -2, getden 2)
sampling the path with kptopt 0, an explicit kpt2 list and istwfk 1
(full G-sphere storage; the unfolding reader requires iomode 3, istwfk 1,
prtwf 1, and chkprim 0 for the non-primitive supercell).

EXPECTED RUNTIME
----------------
  python reproduce.py with only the corner fixtures: a few
    seconds per figure (single-core).
  Dense regeneration: Si8 305-point path ~20 min on 8 cores; Si7P and
    the primitive reference are similar or cheaper. Disk: the dense
    Si8/Si7P WFKs are ~787 MB each, the primitive reference ~103 MB.

EXPECTED OUTPUTS
----------------
  si8_abinit_unfolded.png    written in every case
  si7p_abinit_unfolded.png   written in every case
  With only the corner fixtures the maps contain the Gamma/X/W/L corner
  points on the full path axis; after regenerating the dense WFKs the
  script automatically uses them and the maps fill in to the published
  305-point figures (plus the crimson primitive overlay when
  si_prim_patho_DS2_WFK.nc is present).

GHOST-PSEUDOPOTENTIAL HAZARD
----------------------------
Use the pseudopotentials shipped in pseudos/ (trusted ABINIT Pspdir fhi
files). An earlier version of these fixtures used a locally generated
ONCVPSP-4.0.1 file whose header ABINIT misparses (lloc read as 4): that
silently adds flat ghost bands below the valence manifold and puts the
Fermi level inside the valence -- pristine Si renders as a metal. The
tell-tale is a Gamma-point spectrum with extra singlets below the top
valence triplet. If you swap in your own pseudos, re-check the Gamma
spectrum first.
