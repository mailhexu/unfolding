Unfolding example bundle: ABINIT DDB phonons
============================================

This bundle reproduces the "ABINIT DDB phonons" example page of the
unfolding documentation: unfolding phonons from an ABINIT DDB
(derivatives database).  The route runs ABINIT's anaddb through abipy to
obtain the supercell eigenvectors along your path, then computes the
unfolding weights with unfolding.DDB_unfolder.

Two documented systems are covered:

  cu       fcc Cu in the CONVENTIONAL cubic cell (natom=4).  The page's
           subtlety is the k-path frame: ase's get_special_points
           returns fcc PRIMITIVE-frame points (X=(1/2,0,1/2) ...),
           while abipy interprets qptbounds in the fractional frame of
           the cell stored in the DDB -- here the conventional cubic
           basis (X=(0,1,0), W=(1/2,1,0), L=(1/2,1/2,1/2)).  Convert
           with the supercell matrix: k_conv = k_prim @ sc_mat.
           Skipping that multiplication silently plots the wrong path.

  catio3   CaTiO3 Pnma (20 atoms, a-minus b-plus a-minus tilts)
           unfolded onto the pseudo-cubic cell along Gamma-X-M-Gamma-R
           (vertices already in the DDB frame), with dipdip=0 toggling
           the dipole-dipole (LO-TO) treatment.

The two bundled DDBs (data/out_DDB, 97 kB and data/out.DDB, 1.8 MB) are
the committed example files behind the published figures on the docs
page (cu_fcc_unfolded.png and catio3_unfolded.png).

For a pristine crystal the weights are exactly 0 or 1: each supercell
mode folds from a single primitive momentum.  CaTiO3's anti-phase and
in-phase octahedral tilts mix the pseudo-cubic fold sectors, so its
modes carry genuine fractional pseudo-cubic character -- exactly the
physics the unfolding exposes.  The unfolder resolves the character-sum
gauge of the DDB eigenvectors and degenerate crossings automatically.

Contents
--------
reproduce.py            run the unfolding (or DDB summary) and save
README.txt              this file
data/out_DDB            committed Cu DDB  (conventional cubic cell)
data/out.DDB            committed CaTiO3 DDB (Pnma cell)
inputs/cu_phonon_scf.in, inputs/cu_phonon_rf.in
                        runnable ABINIT deck pair (Cu) reproducing a DDB
                        like data/out_DDB; parameters reconstructed from
                        the DDB header
inputs/catio3_phonon_scf.in, inputs/catio3_phonon_rf.in
                        same for CaTiO3
pseudos/Ca.psp8, Ti-sp.psp8, O.psp8
                        PAW pseudopotentials matching the CaTiO3 DDB
                        header (Ca zion 10, Ti zion 12, O zion 6; from
                        the abipy distribution).  For Cu bring your own
                        Cu PAW pseudo (zion 19).

Prerequisites
-------------
Tested with (mydev environment, 2026-09):
  python 3.11, numpy, matplotlib, ase, spglib
  abipy 1.0.0
  unfolding  (pip install "unfolding[abipy]", or the repository root on
              PYTHONPATH)
PLUS a working anaddb binary (shipped with ABINIT) -- on PATH or
configured in ~/.abinit/abipy/manager.yml.  The bundled DDBs are parsed
and summarized with pure python (no anaddb needed); only the unfolding
step calls anaddb.

How to run
----------
    tar xf abinit-ddb.tar.gz && cd abinit-ddb

  # Cu, using the bundled DDB (needs anaddb):
  python reproduce.py
      -> data/out_DDB is parsed, summarized (cu_ddb_summary.txt), and
         unfolded along Gamma-X-W-Gamma-L -> cu_unfolded.png

  # CaTiO3:
  python reproduce.py --system catio3
      -> catio3_unfolded.png

  # without anaddb: still parses the DDB and writes the summary
  python reproduce.py --summary-only

Options: --ddb PATH (default data/out_DDB / data/out.DDB), --output FILE,
--system {cu,catio3}, --summary-only.

Expected runtime: seconds for the parse/summary; the unfolding itself
runs anaddb with ndivsm=40 along the path (nqsmall=2 interpolation,
asr=1, chneut=1, lo_to_splitting on for Cu) -- typically a couple of
minutes for Cu, longer for CaTiO3.

Producing your own DDB
----------------------
To unfold YOUR structure, produce a supercell DFPT DDB with ABINIT:

  1. ground-state SCF run (iscf 7 + occopt/tsmear or fixed occ),
  2. DFPT run: optdriver 1, rfphon 1, rfatpol 1 natom, rfdir 1 1 1,
     qpt per mesh point, prtddb 1  ->  out_DDB,
  3. merge partial DDBs with mrgddb when needed.

inputs/ contains runnable deck pairs for both bundled systems with the
parameters recorded in the DDB headers.  Then:

  python reproduce.py --ddb /path/to/your_DDB --system cu   (frame logic
  of the cu snippet generalizes; adapt sc_mat and the path to YOUR cell)

Frame conventions recap (the cu case)
-------------------------------------
  sc_mat = inv([[0,1,1],[1,0,1],[1,1,0]] / 2)   supercell (conventional
           cubic cell) in primitive-lattice units, rows convention
           S = A_prim @ sc_mat; this symmetric matrix also converts
           primitive-frame fractional k-points to the DDB frame:
           k_conv = k_prim @ sc_mat, e.g. X: (1/2,0,1/2) -> (0,1,0).
  DDB_unfolder(DDB, sc_mat=sc_mat, kpath_bounds=k_conv, knames=...)
           runs anaddb (nqsmall=2, asr=1, chneut=1, lo_to_splitting,
           ndivsm=40) and plots weights vs frequency in cm^-1.

Weight conventions: anaddb eigenvectors keep the full Bloch phase while
phonopy folds it out; the unfolder's gauge-robust Bloch-sum projectors
with degenerate-group resolution keep pristine weights binary in either
gauge.
