====================================================================
SIESTA spinor (nspin=4) unfolded bands -- reproduction bundle
(siesta-spinor)
====================================================================
Docs example: docs/content/examples/siesta-spinor.md in the unfolding
repository. Regenerates the figure si_spinor_unfolded.png: the
pristine Si supercell run non-collinearly (SpinPolarized true +
Spin.Orbit true, nspin=4) unfolded onto the primitive fcc cell along
Gamma-X-W-Gamma-L-W-X, with the spinor primitive-cell bands overlaid
in red. The scalar Si pseudopotential has no SOC channels, so the
spinor bands equal the scalar bands with Kramers degeneracy -- the
figure certifies the spinor machinery end to end (parse -> relabel ->
weights), not spinor physics. Spinor orbital counts are doubled:
8 per atom (4 PAO x 2 spin components).

BUNDLE LAYOUT
  reproduce.py   self-contained script; regenerates the figure
  data/          working copies of the fdf files; the .HSX outputs of
                 the SCF runs are placed here (NOT shipped: binary data)
                 si_prim_pso.fdf / si_prim_pso.HSX  primitive, nspin=4
                 si_sc_pso.fdf   / si_sc_pso.HSX    supercell,  nspin=4
                 Each fdf sits next to its .HSX because the parser
                 resolves the Hamiltonian archive relative to the fdf.
  inputs/        the same fdf SIESTA inputs (for re-running SIESTA
                 from scratch); data/ keeps the working copies
  pseudos/       pseudopotential notes (see PSEUDOPOTENTIALS below)

PREREQUISITES
  - Python 3.11 with
      numpy 2.2.4, scipy 1.16.0, matplotlib 3.11.2,
      sisl 0.16.2, HamiltonIO 0.3.6,
    and the unfolding package importable (pip install -e <unfolding
    repo checkout>, or PYTHONPATH=<unfolding repo checkout>).
    Tested with unfolding 0.1.0 at main commit 668dde2.
  - A SIESTA installation is needed to (re)generate the .HSX files;
    the bundle ships the fdf inputs and pseudos instead of binary HSX.

HOW THE FIXTURES WERE PRODUCED
  SIESTA development build (>= 5.4, gcc13), GGA/PBE, SZ PAO basis,
  MeshCutoff 100 Ry, SaveHS true, with the non-collinear switches
  SpinPolarized true and Spin.Orbit true (nspin=4).
    si_prim_pso: 2-atom fcc primitive cell, 4x4x4 k-grid SCF.
    si_sc_pso:   8-atom conventional cubic supercell
                 (supercell = [[-1,1,1],[1,-1,1],[1,1,-1]] @ primitive),
                 2x2x2 k-grid SCF (matched to the primitive 4x4x4).
  A k-sampled SCF is essential: a Gamma-only SaveHS run collapses all
  supercell image shells into a single R=0 block, which cannot be
  unfolded at generic momenta. The regeneration recipe is
  examples/si_example/regenerate_fixtures.sh in the unfolding repo.

COMMANDS
  python reproduce.py                # writes si_spinor_unfolded.png
  python reproduce.py out.png        # or any output path

EXPECTED OUTPUT
  si_spinor_unfolded.png (859x650 px, 150 dpi): weight-coded spinor
  unfolded spectrum with tick labels Gamma X W Gamma L W X and the
  spinor primitive-cell bands overlaid in crimson; every branch shows
  the doubled (Kramers) degeneracy of the scalar spectrum. Runtime:
  about 13 s on one core of an Intel i9-13900KF.
  Note: the script reproduces the current docgen pipeline
  (docgen/fig_siesta_spinor.py) bit-for-bit; if the PNG published on
  the docs page looks older (different weight colormap), the page
  image predates the current pipeline.

PSEUDOPOTENTIALS
  The fdf files name Si.psf (Si, norm-conserving). That file is NOT
  included in this bundle and is NOT needed to reproduce the figure:
  the committed .HSX already carries the Hamiltonian and overlap, and
  the parser never opens the pseudo. You only need Si.psf to re-run
  SIESTA from scratch; it comes from the SIESTA distribution's
  Examples/Si_Optical set (place it next to the fdf inputs).
  See pseudos/PLACEHOLDER-NOT-INCLUDED.txt.
