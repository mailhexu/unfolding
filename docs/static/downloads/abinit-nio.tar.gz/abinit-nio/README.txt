ABINIT WFK unfolding bundle: type-II antiferromagnetic NiO
==========================================================

WHAT THIS EXAMPLE SHOWS
-----------------------
Unfolding of a magnetic supercell: type-II AFM NiO (Ni moments alternating
along [111], local moments +/-1.36 mu_B totalling zero) described in the
4-atom magnetic primitive cell, A_afm = M @ A_prim with

  M = [[1, 0, 1], [0, 1, 1], [1, 1, 0]]

(i.e. the 2-atom rocksalt primitive cell doubled along [111]), unfolded
back onto the 2-atom rocksalt primitive cell along the fcc path
Gamma-X-W-Gamma-L-W-X. The collinear WFK (nsppol 2) stores two separate
spin channels and the unfolding weight of a state is computed within its
own channel, so no spin mixing is involved. Because the type-II AFM keeps
inversion symmetry, time reversal followed by the sublattice translation
maps the spin-down Hamiltonian onto the spin-up one at the same momentum:
both channels have identical band energies AND identical unfolding weights
(verified to < 0.05 eV everywhere), so a single spin-up panel is plotted.
Pass spin=1 to compute the identical partner. Systems without that
symmetry (ferrimagnets, AFMs without inversion) do show distinct channels;
the recipe is the same.

The AFM character shows up as the exchange-split branches of the two Ni
sublattices folded from the magnetic cell. Note the physics level of the
input: plain PBE (ixc 11) makes the moment small and the gap close, so
the plotted window shows a metal-like spectrum; a Hubbard U restores the
insulator without changing the unfolding recipe. The Ni-3s semicore
multiplet near -60 eV (the pseudopotential carries 18 valence electrons)
is out of the plotted window (-16 to +8 eV).

One figure is produced:

  nio_afm_unfolded.png   AFM NiO unfolded onto the 2-atom primitive cell
                         (spin-up channel; spin-down identical by symmetry)

BUNDLE LAYOUT
-------------
  inputs/    ABINIT input files (two-dataset decks: AFM SCF + non-SCF path)
             nio_afm.abi           4x4x4 SCF + dense 305-point path (ecut 40)
             nio_afm_corners.abi   same SCF + Gamma/X/W/L corners only
                                   (generates the included small fixture)
  pseudos/   Ni.psp8, O.psp8 (norm-conserving, Ni with 18 valence electrons)
  data/      nio_afm_cornerso_DS2_WFK.nc  corner-only path WFK fixture (~16 MB)
  reproduce.py  renders the figure; run from this directory

PREREQUISITES
-------------
  - Python >= 3.9 with numpy and matplotlib
  - the "unfolding" package, importable (pip install unfolding, or put
    the repository root on PYTHONPATH)
  - only for regenerating the dense WFK: ABINIT >= 9 built with netCDF
    support (the decks use iomode 3)

EXACT COMMANDS
--------------
Unpack and run from the bundle directory (the directory containing this
README):

  python reproduce.py

That is all: the figure is rendered from the included corner fixture.
All ABINIT decks reference their pseudopotentials via pp_dirpath "." --
run ABINIT in a directory holding the .abi plus the pseudos (see the
printed recipe).

To reproduce the full 305-point published figure, also run the dense deck
(reproduce.py prints these exact commands when the dense WFK is missing):

  mkdir -p run_nio && cd run_nio
  cp ../inputs/nio_afm.abi ../pseudos/Ni.psp8 ../pseudos/O.psp8 .
  abinit nio_afm.abi > nio_afm.abo 2>&1
  cp nio_afmo_DS2_WFK.nc ../data/ && cd ..

The deck is a two-dataset run at ecut 40 with nsppol 2 / nspden 2 and
spinat-given type-II AFM moments (0 0 +2 on the first Ni, 0 0 -2 on the
second): dataset 1 is the AFM SCF on a 4x4x4 mesh (kptopt 1), dataset 2 a
frozen-density non-SCF run (iscf -2, getden 2) over the 305-point
supercell path with kptopt 0 and istwfk 1. The unfolding reader requires
iomode 3, istwfk 1, prtwf 1; chksymbreak 0 is set because the magnetic
cell breaks the rocksalt symmetry check.

EXPECTED RUNTIME
----------------
  python reproduce.py with only the corner fixture: a few seconds
    (single-core).
  Dense regeneration: the 4x4x4 AFM SCF dominates; expect on the order of
    hours (the published run took ~1 h with 8 MPI ranks) and ~1.1 GB for
    the dense WFK.

EXPECTED OUTPUTS
----------------
  nio_afm_unfolded.png  written in every case. With only the corner
  fixture the map contains the Gamma/X/W/L corner points on the full path
  axis; after regenerating the dense WFK the script automatically uses it
  and the map fills in to the published 305-point figure.
