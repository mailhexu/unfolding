Unfolding example bundle: Phonopy Cu phonons
============================================

This bundle reproduces the "Phonopy Cu phonons" example page of the
unfolding documentation: the phonon band structure of a 3x3x3 fcc Cu
supercell unfolded onto the primitive fcc Brillouin zone along
Gamma-X-W-Gamma-L.

What the example shows
----------------------
For a pristine crystal every supercell phonon folds from exactly one
primitive momentum, so the unfolding weights are binary (0 or 1).  In the
figure only the three modes folding onto the current primitive momentum
carry weight 1: three bold branches trace the primitive Cu dispersion while
the other 24 folded copies stay invisible.  In a defective or distorted
supercell the same plot would show fractional weights.

The bundle is self-generating: it needs NO DFT run and ships no fixtures.
reproduce.py builds the phonopy inputs (SPOSCAR + FORCE_CONSTANTS for the
27-atom supercell) from a simple analytic force-constant spring model,
then runs the documented `phonopy_unfold` call from
unfolding.phonopy_unfolder and saves the weight-coded figure.

Note on faithfulness: the figure published on the documentation page was
generated from abinit force constants (the committed examples/phonopy
fixture).  This bundle approximates those force constants with springs to
the first two fcc neighbour shells, so the dispersion shape is
approximate; the unfolding physics demonstrated (binary weights, three
bold branches) is identical.  To reproduce the published curve exactly,
drop a real FORCE_CONSTANTS/SPOSCAR pair next to reproduce.py and run
with --skip-generate.

Contents
--------
reproduce.py    generate inputs + run the unfolding + save the figure
README.txt      this file

(FORCE_CONSTANTS, SPOSCAR and unfolded_band_structure.png are produced by
the script in the working directory.)

Prerequisites
-------------
Tested with (mydev environment, 2026-09):
  python 3.11, numpy, matplotlib
  phonopy 4.1.0
  ase 3.29.0
  spglib 2.7.0
  unfolding  (pip install "unfolding[phonopy]", or put the repository
              root on PYTHONPATH)

How to run
----------
    tar xf phonopy-cu.tar.gz && cd phonopy-cu
    python reproduce.py

The script writes, in the current directory:
  FORCE_CONSTANTS               27x27 force constants (spring model)
  SPOSCAR                       27-atom 3x3x3 supercell of primitive fcc Cu
  unfolded_band_structure.png   weight-coded unfolded band figure (300 dpi)

Expected runtime: under 5 seconds on a laptop (no DFT involved).

Options
-------
  --a FLOAT          fcc lattice constant in Angstrom (default 3.61)
  --npoints INT      q-points along the path (default 300)
  --output FILE      output figure name (default unfolded_band_structure.png)
  --fc FILE          FORCE_CONSTANTS path (default ./FORCE_CONSTANTS)
  --sposcar FILE     SPOSCAR path (default ./SPOSCAR)
  --skip-generate    reuse an existing FORCE_CONSTANTS/SPOSCAR pair instead
                     of regenerating them (use this to plug in real DFT
                     force constants)

How it works (the two matrices)
-------------------------------
  sc_mat = diag(1,1,1)       describes the cell stored in SPOSCAR (used as
                             is: the SPOSCAR itself is the unfolded cell)
  unfold_sc_mat = diag(3,3,3)
                             the supercell the force constants belong to;
                             primitive-frame q-points are multiplied by it
                             before the supercell dynamical matrix is
                             evaluated
Frequencies are read from phonopy in THz and converted to cm^-1 for
plotting.  Lower-level staging is available in the package:
read_phonopy(sposcar, sc_mat, force_constants=...) builds the phonopy
object (it also accepts disp_yaml/force_sets), and
unf(phonon, sc_mat, qpoints, ...) runs the unfolding step alone.
