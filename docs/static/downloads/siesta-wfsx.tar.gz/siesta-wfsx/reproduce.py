#!/usr/bin/env python
"""Reproduce the WFSX-driven Si unfolded-band figure
(si_wfsx_unfolded.png).

Docs example: docs/content/examples/siesta-wfsx.md in the unfolding
repo. Same path and physics as the Hamiltonian-route example, but the
eigenvalues and coefficients come from the committed SIESTA WFSX path
run instead of diagonalizing H: the weight formula still uses the HSX
overlap shells, only the eigen-solve is replaced by SIESTA's own
wavefunctions. The overlay is the independently computed primitive-cell
band structure (raw energies); WFSX energies are Fermi-shifted, so the
run's EIG-header Fermi energy is subtracted here.

Run from the unpacked bundle directory (this file's directory):

    python reproduce.py [output.png]

Requires the ``unfolding`` package importable (pip install -e <unfolding
repo checkout>, or PYTHONPATH=<unfolding repo checkout>) plus numpy,
scipy, matplotlib, sisl and HamiltonIO >= 0.3.6 (SiestaWFSXParser). No
SIESTA run is needed: the fixtures in data/ are committed.
"""
import os
import sys

import matplotlib

matplotlib.use("Agg")

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")

B = np.array([[-1, 1, 1], [1, -1, 1], [1, 1, -1]])  # conv cell = B @ prim
PATH = "GXWGLWX"
NPTS = 150  # matches the committed WaveFuncKPoints path list

# fcc high-symmetry points in primitive reciprocal fractional coordinates
# (Setyawan-Curtarolo values).
SPECIAL = {
    "G": (0.0, 0.0, 0.0),
    "X": (0.5, 0.0, 0.5),
    "W": (0.5, 0.25, 0.75),
    "K": (0.375, 0.375, 0.75),
    "L": (0.5, 0.5, 0.5),
    "U": (0.625, 0.25, 0.625),
}


def read_si_model(fdf):
    """Parse a SIESTA fdf (+ sibling .HSX) through the production path."""
    from HamiltonIO.siesta.sisl_wrapper import SislParser

    class RListParser(SislParser):
        def read_Rlist(self, geom=None):
            return self.ham.lattice.sc_off

    return RListParser(fdf).get_model()


def path_grid(npts=NPTS):
    """k-grid over PATH in primitive fractional coordinates.

    Returns ``(kpts, seg_starts)``; segment point counts are
    proportional to Cartesian length.
    """
    cell = np.array([[0.0, 0.5, 0.5], [0.5, 0.0, 0.5], [0.5, 0.5, 0.0]]) * 5.430
    bcart = 2 * np.pi * np.linalg.inv(cell).T
    segs = list(zip(PATH, PATH[1:]))
    lengths = [
        np.linalg.norm((np.array(SPECIAL[b]) - np.array(SPECIAL[a])) @ bcart)
        for a, b in segs
    ]
    total = sum(lengths)
    kpts, seg_starts = [], []
    for i, (a, b) in enumerate(segs):
        pa, pb = np.array(SPECIAL[a]), np.array(SPECIAL[b])
        n = max(2, round(npts * lengths[i] / total) + 1)
        last = i == len(segs) - 1
        t = np.linspace(0.0, 1.0, n, endpoint=last)
        seg_starts.append(len(kpts))
        kpts.extend(pa + (pb - pa) * t[:, None])
    return np.array(kpts), seg_starts


def prim_bands(prim, kfrac):
    """Primitive-cell eigenvalues along the path, shape (nk, n_orb_prim)."""
    from scipy.linalg import eigh

    from unfolding.lcao_unfolder import HamiltonIOModel

    pm = HamiltonIOModel(prim)
    return np.array([eigh(*pm.hs_and_eigen(k), eigvals_only=True) for k in kfrac])


def main(out_path):
    import matplotlib.pyplot as plt

    from HamiltonIO.siesta.wfsx import SiestaWFSXParser

    from unfolding.lcao_unfolder import HamiltonIOModel, LCAOUnfolder
    from unfolding.mapping import RelabelMap
    from unfolding.plotphon import plot_band_weight
    from unfolding.wfsx_unfolder import WFSXUnfolder

    prim = read_si_model(os.path.join(DATA, "si_prim.fdf"))
    sc = read_si_model(os.path.join(DATA, "si_sc.fdf"))

    sc_model = HamiltonIOModel(sc)
    rm = RelabelMap.from_atoms(
        sc.atoms,
        prim.atoms,
        B,
        orb_counts_sc=[4] * 8,
        orb_counts_prim=[4, 4],
    )

    cell = np.asarray(sc.atoms.cell)
    wfsx = SiestaWFSXParser(
        os.path.join(DATA, "si_sc_path.selected.WFSX"), cell=cell
    ).read()

    with open(os.path.join(DATA, "si_sc_path.EIG")) as fh:
        e_fermi = float(fh.readlines()[0])

    unf = WFSXUnfolder(wfsx, sc_model, rm, B)
    kprim, seg_starts = path_grid()
    res = unf.compute(kprim, method="ideal")

    bcart = 2 * np.pi * np.linalg.inv(np.asarray(prim.atoms.cell)).T
    x = np.concatenate(
        [[0.0], np.cumsum(np.linalg.norm(np.diff(kprim, axis=0) @ bcart, axis=1))]
    )
    Xq = [x[i] for i in seg_starts] + [x[-1]]
    knames = [{"G": "\u0393"}.get(s, s) for s in PATH]
    eprim = prim_bands(prim, kprim)

    nb = res.weights.shape[1]
    kslist = [list(x) for _ in range(nb)]
    ekslist = [list(res.eigenvalues[:, ib] - e_fermi) for ib in range(nb)]
    wkslist = [list(np.clip(res.weights[:, ib], 0.0, 1.0)) for ib in range(nb)]

    ax = plot_band_weight(
        kslist,
        ekslist,
        wkslist,
        xticks=[knames, Xq],
        ylabel="Energy (eV)",
        ypad=1.5,
    )
    lines = ax.plot(x, eprim, color="crimson", lw=1.0, alpha=0.9, zorder=5)
    lines[0].set_label("primitive-cell bands")
    ax.legend(loc="upper right", fontsize=8, framealpha=0.85)
    ax.figure.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(ax.figure)
    return out_path


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "si_wfsx_unfolded.png"
    print("wrote", main(out))
