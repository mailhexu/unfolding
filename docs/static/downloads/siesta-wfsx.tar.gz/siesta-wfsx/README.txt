====================================================================
SIESTA WFSX-route unfolded bands -- reproduction bundle (siesta-wfsx)
====================================================================
Docs example: docs/content/examples/siesta-wfsx.md in the unfolding
repository. Regenerates the figure si_wfsx_unfolded.png: the same Si
spectrum as the Hamiltonian route, but the eigenvalues and
coefficients come from SIESTA's own stored wavefunctions (a WFSX file
written along the unfolding path) instead of diagonalizing H. The
weight formula still uses the HSX overlap shells; only the eigen-solve
is replaced. WFSX energies are Fermi-shifted by the writing run, so
the EIG-header Fermi energy is subtracted before plotting; the
primitive-cell bands (raw energies) are overlaid in red.

BUNDLE LAYOUT
  reproduce.py   self-contained script; regenerates the figure
  data/          committed WFSX + EIG path-run fixtures (small); the
                 SCF .HSX files are NOT shipped (binary data) - place
                 them here after regenerating
                 si_prim.fdf / si_prim.HSX        primitive cell
                 si_sc.fdf   / si_sc.HSX          supercell (overlap
                                                  shells for the weight)
                 si_sc_path.selected.WFSX         wavefunctions along
                                                  the unfolding path
                 si_sc_path.EIG                   header carries the
                                                  run's Fermi energy
                 Each fdf sits next to its .HSX because the parser
                 resolves the Hamiltonian archive relative to the fdf.
  inputs/        SIESTA inputs for re-running the calculations,
                 including si_sc_path.fdf -- the exact supercell input
                 (SaveWFSX true + %block WaveFuncKPoints along
                 Gamma-X-W-Gamma-L-W-X) that produced the committed
                 WFSX/EIG pair
  pseudos/       pseudopotential notes (see PSEUDOPOTENTIALS below)

PREREQUISITES
  - Python 3.11 with
      numpy 2.2.4, scipy 1.16.0, matplotlib 3.11.2,
      sisl 0.16.2, HamiltonIO >= 0.3.6 (SiestaWFSXParser),
    and the unfolding package importable (pip install -e <unfolding
    repo checkout>, or PYTHONPATH=<unfolding repo checkout>).
    Tested with unfolding 0.1.0 at main commit 668dde2.
  - No SIESTA installation or run is needed: the fixtures are
    committed in data/.

HOW THE FIXTURES WERE PRODUCED
  SIESTA development build (>= 5.4, gcc13), GGA/PBE, SZ PAO basis,
  MeshCutoff 100 Ry.
    SCF runs (same as the pristine Si example):
      si_prim: 2-atom fcc primitive cell, 4x4x4 k-grid SCF, SaveHS.
      si_sc:   8-atom conventional cubic supercell, 2x2x2 k-grid SCF,
               SaveHS true (k-sampled: a Gamma-only SaveHS collapses
               all image shells into one R=0 block that cannot be
               unfolded at generic k).
    Band-structure selection run (the WFSX route):
      si_sc_path.fdf = the same supercell input plus SaveWFSX true and
      %block WaveFuncKPoints (WaveFuncKPointsScale
      ReciprocalLatticeVectors) listing 157 momenta along
      Gamma-X-W-Gamma-L-W-X. The run writes si_sc.selected.WFSX and
      si_sc.EIG, shipped here under the si_sc_path.* names.
  The regeneration recipe is examples/si_example/regenerate_fixtures.sh
  in the unfolding repo.

COMMANDS
  python reproduce.py                # writes si_wfsx_unfolded.png
  python reproduce.py out.png        # or any output path

EXPECTED OUTPUT
  si_wfsx_unfolded.png (859x650 px, 150 dpi): the unfolded spectrum
  from SIESTA's stored wavefunctions (Fermi-shift subtracted), tick
  labels Gamma X W Gamma L W X, primitive-cell bands overlaid in
  crimson; matches the Hamiltonian-route figure without any
  diagonalization of the supercell H. Runtime: about 4 s on one core
  of an Intel i9-13900KF.
  Note: the script reproduces the current docgen pipeline
  (docgen/fig_siesta_wfsx.py) bit-for-bit; if the PNG published on the
  docs page looks older (different weight colormap), the page image
  predates the current pipeline.

PSEUDOPOTENTIALS
  The fdf files name Si.psf (Si, norm-conserving). That file is NOT
  included in this bundle and is NOT needed to reproduce the figure:
  the committed HSX/WFSX/EIG fixtures carry everything the parse /
  unfolding path reads, and the parser never opens the pseudo. You
  only need Si.psf to re-run SIESTA from scratch; it comes from the
  SIESTA distribution's Examples/Si_Optical set (place it next to the
  fdf inputs). See pseudos/PLACEHOLDER-NOT-INCLUDED.txt.
