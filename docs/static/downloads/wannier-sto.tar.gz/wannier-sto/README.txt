Unfolding example bundle: Wannier90 SrTiO3
==========================================

This bundle reproduces the "Wannier90 SrTiO3" example page of the
unfolding documentation: unfolding tight-binding Hamiltonians produced by
Wannier90 -- pristine and defect supercells of SrTiO3 -- onto the
primitive-cell Brillouin zone along Gamma-X-M-Gamma-R.

What the example shows
----------------------
For a pristine supercell every band folds from exactly one primitive
momentum, so the unfolding weights are binary: bold branches trace the
primitive bands and the folded copies stay invisible.  With a defect, the
translation symmetry is broken: defect-derived states appear with
fractional weights while the host bands remain at weight 1 -- the
electronic analogue of the SIESTA dopant example.

The bundled model is SYNTHETIC
------------------------------
The published figures (sto_nodefect.png / sto_defect.png on the docs page)
were computed from Wannier90 runs on 5-atom-cell SrTiO3 supercells
(56 Wannier functions each); their wannier90_hr.dat files are ~38 MB and
are NOT part of this bundle.  Instead the bundle ships a small synthetic
stand-in, data/example_hr.dat, so the script is demonstrably runnable
without DFT:

  * Ti t2g conduction-band model: 3 orbitals (d_xy, d_yz, d_zx) on a
    simple-cubic Ti sublattice, nearest-neighbour hopping t = 1 eV,
    on-site 0 (the standard cubic SrTiO3 conduction-band model),
  * 2x2x2 supercell: 24 orbitals, Wannier90 hr format,
  * --defect weakens the hoppings of one site (to 30%) and raises its
    on-site energy to +6 eV, so partly-localized impurity levels split
    off above the t2g bands with reduced, fractional unfolding weights.

The dispersion is schematic, not fitted to SrTiO3; the unfolding physics
demonstrated (binary pristine weights, fractional defect weights) is the
same as in the published figures.

Contents
--------
reproduce.py               run the unfolding and save the figure
README.txt                 this file
data/example_hr.dat        synthetic t2g model in wannier90_hr.dat format
inputs/seedname.win.example
                           annotated Wannier90 input sketch for producing
                           a real wannier90_hr.dat

Prerequisites
-------------
Tested with (mydev environment, 2026-09):
  python 3.11, numpy, matplotlib, ase
  unfolding  (pip install unfolding, or the repository root on PYTHONPATH)

Optional: minimulti (pip install minimulti) enables the page's documented
convenience route (MyTB reader).  Without it the script falls back to a
minimal built-in hr reader plus the same documented WannierUnfolder
low-level route -- everything still runs, numpy only.

How to run
----------
    tar xf wannier-sto.tar.gz && cd wannier-sto
    python reproduce.py            # pristine  -> sto_unfolded.png
    python reproduce.py --defect   # impurity  -> sto_defect.png

Each run prints the fraction of binary vs fractional weights and writes
the weight-coded figure (300 dpi) in the working directory.  Expected:
the pristine run shows 100% binary weights; the defect run shows
fractional weights on the impurity-derived states (~6 eV flat levels and
their hybridized partners) while host bands stay at weight 1.

Expected runtime: a few seconds.

Options
-------
  --hr PATH            wannier90_hr.dat to read
                       (default data/example_hr.dat)
  --engine {auto,builtin,minimulti}
                       auto (default) uses minimulti's MyTB reader when
                       the package is importable, else the built-in numpy
                       reader; builtin/minimulti force one route
  --prefix NAME        file prefix for the minimulti route (default example)
  --defect             apply the impurity to the synthetic model before
                       unfolding (builtin engine)
  --npoints INT        k-points along the path (default 200)
  --output FILE        output figure (default sto_unfolded.png, or
                       sto_defect.png with --defect)
  --regenerate-hr      rewrite the bundled synthetic data/example_hr.dat

Note on labels: WannierUnfolder expects ONE LABEL PER SUPERCELL ORBITAL
(e.g. the bundled model uses d_xy/d_yz/d_zx x 8 sites; the shipped
repository example for real SrTiO3 uses ['pz','px','py']*12 +
['dz2','dxy','dyz','dx2','dxz']*4).  For your own hr.dat, pass labels
matching its number of Wannier functions.

How to produce a real wannier90_hr.dat
--------------------------------------
Run Wannier90 on your supercell (for SrTiO3: e.g. a 2x2x2 supercell of
the 5-atom cell, or the Pnma 20-atom cell as in the published example)
and request the Hamiltonian in real space.  Minimal seedname.win sketch:

  num_bands     = <nband>
  num_wann      = <num_wann>
  dis_win_min   = ...
  dis_win_max   = ...
  dis_froz_min  = ...
  dis_froz_max  = ...
  projections   = Ti:d; O:p
  begin projections
    ... (or explicit centres)
  end projections

  begin kpoint_path
    ... (band-structure path for the Wannier interpolation check)
  end kpoint_path

  ! the supercell k-grid used for the Wannierisation:
  mp_grid      = 2 2 2
  begin kpoints
    ... (2x2x2 = 8 reduced points)
  end kpoints

  write_hr = true          ! -> seedname_hr.dat
  write_lm = .false.
 use_blobs = .false.

After wannier90.x seedname (-pp first for the initial projection pass)
you get seedname_hr.dat; run this bundle's script with --hr pointing at
it.  The unfolding route is generic for any Wannier-derived (or other)
tight-binding model that can solve the supercell generalized
eigenproblem; centres (seedname_centres.xyz) are optional but useful.

Low-level route (documented on the example page)
------------------------------------------------
WannierUnfolder only needs a model object exposing .atoms (ASE Atoms of
the primitive cell), ._orb (scaled orbital positions of the supercell
model) and .solve_all(k_list=..., eig_vectors=...) returning supercell
eigenpairs; the built-in engine's SimpleTB class in reproduce.py is a
minimal worked example of that interface.
