====================================================================
Si:P substitutional-dopant unfolded bands -- reproduction bundle
(siesta-p-doped)
====================================================================
Docs example: docs/content/examples/siesta-p-doped.md in the
unfolding repository. Regenerates the figure si_p_doped_unfolded.png:
the committed Si7P supercell (one Si replaced by P, 8 atoms,
2x2x2 k-grid SCF) unfolded onto the 2-atom primitive fcc cell along
Gamma-X-W-Gamma-L-W-X. Host bands -- states essentially unchanged
from ideal Si -- keep weight 1; donor/impurity-derived states appear
at reduced weight spread over several fold sectors. The dopant site
maps onto the host site it replaces (match_species=False).

BUNDLE LAYOUT
  reproduce.py   self-contained script; regenerates the figure
  data/          working copies of the fdf files; the .HSX outputs of
                 the SCF runs are placed here (NOT shipped: binary data)
                   si_prim.fdf  / si_prim.HSX    pristine primitive cell
                   si_sc_p.fdf  / si_sc_p.HSX    Si7P doped supercell
                 Each fdf sits next to its .HSX because the parser
                 resolves the Hamiltonian archive relative to the fdf.
  inputs/        the same fdf SIESTA inputs (for re-running SIESTA
                 from scratch); data/ keeps the working copies
  pseudos/       P.psml (included) + a note on Si.psf (not included)

PREREQUISITES
  - Python 3.11 with
      numpy 2.2.4, scipy 1.16.0, matplotlib 3.11.2,
      sisl 0.16.2, HamiltonIO 0.3.6,
    and the unfolding package importable (pip install -e <unfolding
    repo checkout>, or PYTHONPATH=<unfolding repo checkout>).
    Tested with unfolding 0.1.0 at main commit 668dde2.
  - A SIESTA installation is needed to (re)generate the .HSX files;
    the bundle ships the fdf inputs and pseudos instead of binary HSX.

HOW THE FIXTURES WERE PRODUCED
  SIESTA development build (>= 5.4, gcc13), GGA/PBE, SZ PAO basis,
  MeshCutoff 100 Ry, SaveHS true, ElectronicTemperature 25 meV.
    si_prim:  2-atom fcc primitive cell (pristine Si), 4x4x4 k-grid SCF.
    si_sc_p:  8-atom conventional cubic supercell with one Si
              substituted by P (species 2), 2x2x2 k-grid SCF.
  A k-sampled SCF is essential: a Gamma-only SaveHS run collapses all
  supercell image shells into a single R=0 block, which cannot be
  unfolded at generic momenta. The regeneration recipe is
  examples/si_example/regenerate_fixtures.sh in the unfolding repo.

COMMANDS
  python reproduce.py                # writes si_p_doped_unfolded.png
  python reproduce.py out.png        # or any output path

EXPECTED OUTPUT
  si_p_doped_unfolded.png (859x650 px, 150 dpi): weight-coded unfolded
  bands with tick labels Gamma X W Gamma L W X and the pristine Si
  primitive-cell bands overlaid in crimson. Host branches sit at
  weight 1 (crimson on crimson); impurity-derived states drop below 1
  and stand out against the red overlay. Runtime: about 5 s on one
  core of an Intel i9-13900KF.
  Note: the script reproduces the current docgen pipeline
  (docgen/fig_siesta_p_doped.py) bit-for-bit; if the PNG published on
  the docs page looks older (different weight colormap), the page
  image predates the current pipeline.

PSEUDOPOTENTIALS
  si_sc_p.fdf references two pseudopotentials:
    Si.psf -- NOT included (absent from the unfolding repository).
      Not needed for the reproduction (the committed .HSX carries the
      Hamiltonian/overlap; the parser never opens the pseudo). To
      re-run SIESTA from scratch, take Si.psf from the SIESTA
      distribution's Examples/Si_Optical set.
    P.psml -- INCLUDED in pseudos/ (phosphorus, norm-conserving
      scalar-relativistic PBE, PSML v1.1 from the PseudoDojo; copied
      from examples/si_example/P.psml in the unfolding repository).
      Place both files next to the fdf inputs when re-running SIESTA.
  See pseudos/PLACEHOLDER-NOT-INCLUDED.txt for the Si.psf note.
